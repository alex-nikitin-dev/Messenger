﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using ErrorsProcessingLib;

namespace MessengerServer
{
    [Serializable]
    public struct ParamsStruct
    {
        public int    messageDelay;
        public int    BWDelay;
        public int    BlackMulti;
        public int    GeneralMulti;
        public bool   AutoStart;
        public bool   ForceDebug;
    }
    public class Parametres
    {
        public ParamsStruct  _params;
        static ParamsStruct  _params_default;
        public static string _path = Application.StartupPath + "\\config.bin";
        private static bool  _debug = false;
        static Parametres()
        {
            _params_default.messageDelay = 10;
            _params_default.BWDelay      = 1000;
            _params_default.BlackMulti   = 2;
            _params_default.GeneralMulti = 3;
            _params_default.AutoStart    = false;
            _params_default.ForceDebug   = false;
        }
        public  Parametres()
        {
#if DEBUG 
            _debug = true;
#endif
        }
        public Parametres(ParamsStruct ps)
        {
            _params = ps;
#if DEBUG
            _debug = true;
#endif
        }
        public  void Save()
        {
            try
            {
                FileStream fs = new FileStream(_path,FileMode.Create,FileAccess.Write);

                BinaryFormatter bf = new BinaryFormatter();

                bf.Serialize(fs,_params);

                fs.Close();
            }
            catch(Exception _E)
            {
                ErrorsProc.WriteErrorAndMessage(_E, "Save in Parametres.cs", _debug);
            }
        }
        /// <summary>
        /// Если файла настроек нет, то будет создан по умолчанию
        /// </summary>
        /// <returns></returns>
        public static ParamsStruct Load()
        {
            try
            {
                FileStream fs = null;
                while (fs == null)
                {
                    try
                    {
                        fs = new FileStream(_path, FileMode.Open, FileAccess.Read);
                    }
                    catch (FileNotFoundException _E)
                    {
                        ErrorsProc.WriteErrorAndMessage(_E, "Load in Parametres.cs", false);

                        Parametres prm = new Parametres(_params_default);
                        
                        prm.Save();
                        
                    }
                }
                BinaryFormatter bf = new BinaryFormatter();

                ParamsStruct Value = (ParamsStruct)bf.Deserialize(fs);

                fs.Close();

                return Value;
            }
            catch (Exception _E)
            {
                ErrorsProc.WriteErrorAndMessage(_E, "Load in Parametres.cs", _debug);
                return _params_default;
            }
        }
    }
}
