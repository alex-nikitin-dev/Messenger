﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.IO;
using System.Threading;
using TextOperations;
using ErrorsProcessing;
using System.Reflection;
namespace UserConnectionLib
{
    public delegate void Receive(UserConnection sender, string message);
    public class UserConnection
    {
        #region поля и свойства
        public enum State
        {
            ВСети,
            Занят,
            НетНаМесте,
            СкороВернусь,
            Обед,
            ВПлохомНастроении,
            ОбращатьсяВКрайнемСлучае,
            УстановилЧтоОтключён,
            Отключён
        }

        public bool _debug = false;

        const int BUFER_SIZE = 4096;
        int _SendDelay = 10;
        
        public TcpClient _client;

        private State _state;
        public State  _Состояние
        {
            get { return _state;  }
            set { _state = value; }
        }
        private System.Collections.ArrayList _white = new System.Collections.ArrayList();
        private System.Collections.ArrayList _black = new System.Collections.ArrayList();
        public System.Collections.ArrayList White
        {
            get { return _white; }
            set { _white = value; }
        }
        public System.Collections.ArrayList Black
        {
            get { return _black; }
            set { _black = value; }
        }


        private byte[] _buffer = new byte[BUFER_SIZE];

        private NetworkStream _stream;

        public event Receive Receive;

        private bool isAttached = false;
        public bool IsAttached
        {
            get { return isAttached; }
            set { isAttached = value; }
        }

        private bool isMChatActive = false;
        public bool IsMChatActive
        {
            get { return isMChatActive; }
            set { isMChatActive = value; }
        }

        private string _name = "";
        public string Name
        {
            get { return _name; }
            set 
            {
                if (_Text.IsEmpty(value)) throw new _Exception(_Exception.error.EmptyUserName);
                _name = value;
            }
        }

        private string[] dataArray = null;
        public string[] DataArray
        {
            get { return dataArray; }
            set{
                if (value == null) throw new _Exception(_Exception.error.EmptyDataArray);
                dataArray = value;
            }
        }
        private IPAddress _ip;
        public IPAddress IP
        {
            get { return _ip; }
        }

        private string  _fistName;
        private string  _lastName;
        private string  _email;
        private string  _description;
        private int     _id;

        public int Id
        {
            get
            {
                return _id;
            }
        }
        public string FistName
        {
            get
            {
                return _fistName;
            }
        }
        public string LastName
        {
            get
            {
                return _lastName;
            }
        }
        public string Email
        {
            get
            {
                return _email;
            }
        }
        public string Description
        {
            get
            {
                return _description;
            }
        }
        private string _password = "";
        public string Password
        {
            get
            {
                return _password;
            }
        }

        #endregion

        #region Assembly Attribute Accessors

        string AssemblyTitle(Assembly asm)
        {

            // Get all Title attributes on this assembly
            object[] attributes = asm.GetCustomAttributes(typeof(AssemblyTitleAttribute), false);
            // If there is at least one Title attribute
            if (attributes.Length > 0)
            {
                // Select the first one
                AssemblyTitleAttribute titleAttribute = (AssemblyTitleAttribute)attributes[0];
                // If it is not an empty string, return it
                if (titleAttribute.Title != "")
                    return titleAttribute.Title;
            }
            // If there was no Title attribute, or if the Title attribute was the empty string, return the .exe name
            return System.IO.Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().CodeBase);

        }

        string AssemblyVersion(Assembly asm)
        {
            return asm.GetName().Version.ToString();
        }

        string AssemblyDescription(Assembly asm)
        {

            // Get all Description attributes on this assembly
            object[] attributes = asm.GetCustomAttributes(typeof(AssemblyDescriptionAttribute), false);
            // If there aren't any Description attributes, return an empty string
            if (attributes.Length == 0)
                return "";
            // If there is a Description attribute, return its value
            return ((AssemblyDescriptionAttribute)attributes[0]).Description;

        }

        string AssemblyProduct(Assembly asm)
        {

            // Get all Product attributes on this assembly
            object[] attributes = asm.GetCustomAttributes(typeof(AssemblyProductAttribute), false);
            // If there aren't any Product attributes, return an empty string
            if (attributes.Length == 0)
                return "";
            // If there is a Product attribute, return its value
            return ((AssemblyProductAttribute)attributes[0]).Product;

        }

        string AssemblyCopyright(Assembly asm)
        {

            // Get all Copyright attributes on this assembly
            object[] attributes = asm.GetCustomAttributes(typeof(AssemblyCopyrightAttribute), false);
            // If there aren't any Copyright attributes, return an empty string
            if (attributes.Length == 0)
                return "";
            // If there is a Copyright attribute, return its value
            return ((AssemblyCopyrightAttribute)attributes[0]).Copyright;

        }

        string AssemblyCompany(Assembly asm)
        {

            // Get all Company attributes on this assembly
            object[] attributes = asm.GetCustomAttributes(typeof(AssemblyCompanyAttribute), false);
            // If there aren't any Company attributes, return an empty string
            if (attributes.Length == 0)
                return "";
            // If there is a Company attribute, return its value
            return ((AssemblyCompanyAttribute)attributes[0]).Company;

        }
        #endregion

        private bool L()
        {
            try
            {
                Assembly asm = Assembly.LoadFrom(Application.ExecutablePath);

                string cprt = AssemblyCopyright(asm);
                if (cprt.CompareTo("Copyright © Алексей HukumuH 2006") != 0)
                {
                    return false;
                }
                string cmp = AssemblyCompany(asm);
                if (cmp.CompareTo("Алексей HukumuH") != 0)
                {
                    return false;
                }
                string desc = AssemblyDescription(asm);
                if (desc.CompareTo("По всем вопросам обращаться lehanet@mksat.net,lehamain@yandex.ru") != 0)
                {
                    return false;
                }
                string titl = AssemblyTitle(asm);
                if (titl.CompareTo("MessengerServer") != 0)
                {
                    return false;
                }

                return true;
            }
            catch
            {
                return false;
            }
        }
        #region Конструктор
        public UserConnection(TcpClient client)
        {
#if DEBUG
            _debug = true;
#endif
            if (!L()) { throw new Exception(); }
            try {
                ParamsStruct ps =  Parametres.Load();
                _SendDelay =  ps.messageDelay;
            }
            catch {
            }

            _state = State.ВСети;

            _client = client;
            _ip = ((IPEndPoint)_client.Client.RemoteEndPoint).Address;

            _stream = _client.GetStream();

            _stream.BeginRead(_buffer, 0, _buffer.Length, new AsyncCallback(StreamReceiver), null);

        }
        #endregion

        #region взаимодействие с базой пользователей
        public void FillData()
        {
            try
            {
                UserDataSet.AccountDataTable ds = new UserDataSet.AccountDataTable();
                UserDataSetTableAdapters.AccountTableAdapter adapter = new UserDataSetTableAdapters.AccountTableAdapter();

                lock (this)
                {
                    adapter.Fill(ds);
                    int id = FindUserPosition(_name, ds);
                    if (id == -1)
                    {
                        _name = "";
                        isAttached = false;
                        throw new _Exception(_Exception.error.WrongUserInit);
                    }
                    else if (id > -1)
                    {
                        UserDataSet.AccountRow row = ((UserDataSet.AccountRow)ds.Rows[id]);
                        _id = row.Id;
                        _fistName = row.Firstname;
                        _lastName = row.Lastname;
                        _email = row.Email;
                        _description = row.Description;
                        _password = row.Password;
                    }

                }

                BW_Fill(ds);
            }
            catch (Exception _E){
                ErrorsProc.WriteErrorAndMessage(_E, "FillData in UserConnection.cs",true);
            }
        }

        #region Заполнение белого и чёрного списков
        /// <summary>
        /// когда некогда разбираться с адаптарами :)
        /// </summary>
        public void WhiteListFill()
        {
            try
            {
                lock (this)
                {
                    UserDataSet.WhiteDataTable wt = new UserDataSet.WhiteDataTable();
                    UserDataSetTableAdapters.WhiteTableAdapter wa = new MessengerServer.UserDataSetTableAdapters.WhiteTableAdapter();

                    UserDataSet.AccountDataTable at = new UserDataSet.AccountDataTable();
                    UserDataSetTableAdapters.AccountTableAdapter ad = new UserDataSetTableAdapters.AccountTableAdapter();


                    wa.Fill(wt);
                    ad.Fill(at);

                    _white.Clear();

                    foreach (UserDataSet.WhiteRow row in wt)
                    {
                        if (row.Login == this._id)
                        {
                            _white.Add(at.FindById(row.Friend).Login);
                        }
                    }
                }
            }
            catch (Exception _E){
                ErrorsProc.WriteErrorAndMessage(_E, "WhiteListFill in UserConnection.cs",_debug);
            }
        }
        public void WhiteListFill(UserDataSet.AccountDataTable at)
        {
            try
            {
                lock (this)
                {
                    UserDataSet.WhiteDataTable wt = new UserDataSet.WhiteDataTable();
                    UserDataSetTableAdapters.WhiteTableAdapter wa = new MessengerServer.UserDataSetTableAdapters.WhiteTableAdapter();

                    wa.Fill(wt);

                    _white.Clear();

                    foreach (UserDataSet.WhiteRow row in wt)
                    {
                        if (row.Login == this._id)
                        {
                            _white.Add(at.FindById(row.Friend).Login);
                        }
                    }
                }
            }
            catch (Exception _E){
                ErrorsProc.WriteErrorAndMessage(_E, "WhiteListFill(UserDataSet.AccountDataTable at) in UserConnection.cs", _debug);
            }
        }
        /// <summary>
        /// когда некогда разбираться с адаптарами :)
        /// </summary>
        public void BlackListFill()
        {
            try
            {
                lock (this)
                {
                    UserDataSet.BlackDataTable bt = new UserDataSet.BlackDataTable();
                    UserDataSetTableAdapters.BlackTableAdapter ba = new MessengerServer.UserDataSetTableAdapters.BlackTableAdapter();

                    UserDataSet.AccountDataTable at = new UserDataSet.AccountDataTable();
                    UserDataSetTableAdapters.AccountTableAdapter ad = new UserDataSetTableAdapters.AccountTableAdapter();


                    ba.Fill(bt);
                    ad.Fill(at);

                    _black.Clear();

                    foreach (UserDataSet.BlackRow row in bt)
                    {
                        if (row.Login == this._id)
                        {
                            _black.Add(at.FindById(row.Enemy).Login);
                        }
                    }
                }
            }
            catch(Exception _E){
                ErrorsProc.WriteErrorAndMessage(_E, "BlackListFill in UserConnection.cs", _debug);
            }
        }
        public void BlackListFill(UserDataSet.AccountDataTable at)
        {
            try
            {
                lock (this)
                {
                    UserDataSet.BlackDataTable bt = new UserDataSet.BlackDataTable();
                    UserDataSetTableAdapters.BlackTableAdapter ba = new MessengerServer.UserDataSetTableAdapters.BlackTableAdapter();

                    ba.Fill(bt);

                    _black.Clear();

                    foreach (UserDataSet.BlackRow row in bt)
                    {
                        if (row.Login == this._id)
                        {
                            _black.Add(at.FindById(row.Enemy).Login);
                        }
                    }
                }
            }
            catch (Exception _E){
                ErrorsProc.WriteErrorAndMessage(_E, "BlackListFill(UserDataSet.AccountDataTable at) in UserConnection.cs", _debug);
            }
        }
        public void BW_Fill()
        {
            try
            {
                lock (this)
                {
                    // не используется BlackListFill и WhiteListFill 
                    // чтобы не создавать лишних объектов AccountDataTable и AccountTableAdapter

                    UserDataSet.WhiteDataTable wt = new UserDataSet.WhiteDataTable();
                    UserDataSetTableAdapters.WhiteTableAdapter wa = new MessengerServer.UserDataSetTableAdapters.WhiteTableAdapter();

                    UserDataSet.BlackDataTable bt = new UserDataSet.BlackDataTable();
                    UserDataSetTableAdapters.BlackTableAdapter ba = new MessengerServer.UserDataSetTableAdapters.BlackTableAdapter();

                    UserDataSet.AccountDataTable at = new UserDataSet.AccountDataTable();
                    UserDataSetTableAdapters.AccountTableAdapter ad = new UserDataSetTableAdapters.AccountTableAdapter();

                    ba.Fill(bt);
                    wa.Fill(wt);
                    ad.Fill(at);

                    _white.Clear();
                    _black.Clear();

                    foreach (UserDataSet.WhiteRow row in wt)
                    {
                        if (row.Login == this._id)
                        {
                            _white.Add(at.FindById(row.Friend).Login);
                        }
                    }

                    foreach (UserDataSet.BlackRow row in bt)
                    {
                        if (row.Login == this._id)
                        {
                            _black.Add(at.FindById(row.Enemy).Login);
                        }
                    }

                }

            }
            catch (Exception _E){
                ErrorsProc.WriteErrorAndMessage(_E, "BW_Fill() in UserConnection.cs", _debug);
            }
        }
        public void BW_Fill(UserDataSet.AccountDataTable at)
        {
            try{
                WhiteListFill(at);
                BlackListFill(at);
            }
            catch (Exception _E){
                ErrorsProc.WriteErrorAndMessage(_E, "BW_Fill(UserDataSet.AccountDataTable at) in UserConnection.cs", _debug);
            }
        }
        #endregion

        int FindUserId(string login, UserDataSet.AccountDataTable AccountTable)
        {
            try
            {
                foreach (UserDataSet.AccountRow row in AccountTable.Rows)
                {
                    if (String.Compare(row.Login, login, true) == 0)
                    {
                        return row.Id;
                    }
                }

                return -1;
            }
            catch (Exception _E){
                ErrorsProc.WriteErrorAndMessage(_E, "FindUserId in UserConnection.cs",true);
                return -2;
            }

        }
        int FindUserPosition(string login, UserDataSet.AccountDataTable AccountTable)
        {
            try
            {
                for (int i = 0; i < AccountTable.Rows.Count;i++ )
                {
                    UserDataSet.AccountRow row = (UserDataSet.AccountRow)AccountTable.Rows[i];
                    if (String.Compare(row.Login, login, true) == 0)
                    {
                        return i;
                    }
                }

                return -1;
            }
            catch (Exception _E){
                ErrorsProc.WriteErrorAndMessage(_E, "FindUserPosition in UserConnection.cs", true);
                return -2;
            }

        }
        #endregion

        #region Сетевое взаимодействие
        
        public void StreamReceiver(IAsyncResult ar)
        {
            int     countByte;
            string  message;

            try
            {
                lock (_stream)
                {
                    countByte = _stream.EndRead(ar);
                }

                message = Encoding.GetEncoding(1251).GetString(_buffer, 0, countByte);

                Receive(this, message);

                lock (_stream)
                {
                    _stream.BeginRead(_buffer, 0, _buffer.Length, new AsyncCallback(StreamReceiver), null);
                }

            }
            catch (IOException _E){
                DisconnectEvent(this,DisconnectReason.TERMINATE);
            }
            catch (Exception _E){

                ErrorsProc.WriteErrorToLog(_E.Message, "StreamReceiver in UserConnection.cs");
#if DEBUG
                System.Windows.Forms.MessageBox.Show(   _E.Message + " return StreamReceiver in UserConnection.cs", "Error report", 
                                                        System.Windows.Forms.MessageBoxButtons.OK, 
                                                        System.Windows.Forms.MessageBoxIcon.Error
                                                    );
#endif
            }
        }
        public enum DisconnectReason
        {
            DEFAULT,
            /// <summary>
            /// принудительно завершено
            /// </summary>
            TERMINATE,
            /// <summary>
            /// был вызван метод ShutDown
            /// </summary>
            SHUTDOWN
        }
        public delegate void Disconnect(UserConnection sender, DisconnectReason reason);
        /// <summary>
        /// необходимо закрыть соединение при возникновении этого события
        /// </summary>
        public event Disconnect DisconnectEvent;
        public void CloseConnection()
        {
            try{
                if (_client.Client != null && _client.Client.Connected){
                    _client.Client.Shutdown(SocketShutdown.Both);
                }
            }
            catch(Exception _E){
                ErrorsProc.WriteErrorAndMessage(_E.Message, "CloseConnection in UserConnection.cs",_debug);
            }

        }
        /// <summary>
        /// Этот метод ничего с сокетом не делает!!! он отправляет ДИСКОННЕКТ
        /// </summary>
        public void ShutDown()
        {
            try{
                SendMessage(MESSAGES.DISCONNECT);
            }
            catch (Exception _E){
                ErrorsProc.WriteErrorAndMessage(_E, " ShutDown() in UserConnection.cs", _debug);
            }
            finally{
                DisconnectEvent(this, DisconnectReason.SHUTDOWN);
            }
        }
        #endregion

        #region Отправка сообщений
        public delegate void MessageSend(UserConnection sender, string message);
        public event MessageSend SendMessageEvent;

        public void SendMessage(string message)
        {
            lock (_stream)
            {
                try
                {
                    Thread.Sleep(_SendDelay);
                    StreamWriter sw = new StreamWriter(_stream, Encoding.GetEncoding(1251));
                    sw.Write(message.Trim());
                    sw.Flush();
                }
                catch(Exception _E){
#if DEBUG
                    ErrorsProc.WriteErrorAndMessage(_E, "SendMessage in UserConnection.cs",true);
#endif
                }
                finally{
                    SendMessageEvent(this, message);
//#if DEBUG
//                    _main.ChatAddString("юзеру " + _name + " отправлено сообщение: " + message);
//#endif
                }
            }
        }
        public void SendMessage(MESSAGES message)
        {
            SendMessage(MessagesGetString(message));
        }
        public void SendMessage(MESSAGES message, params string[] additional)
        {
            string send = MessagesGetString(message);
            foreach (string str in additional)
            {
                send += "|" + str;
            }
            SendMessage(send);
        }
        public void SendMessage(MESSAGES message, int delay, params string[] additional)
        {
            Thread.Sleep(delay);
            SendMessage(message, additional);
        }
        public void SendMessage(MESSAGES message, int delay)
        {
            Thread.Sleep(delay);
            SendMessage(message);
        }

        public void SendMessage(string message, int delay)
        {
            Thread.Sleep(delay);
            SendMessage(message);
        }

        #region MESSAGES
        public enum MESSAGES
        {
            /// <summary>
            /// сообщение юзеру что кто-то добавил его в контакты
            /// </summary>
            ALERT,
            /// <summary>
            /// Авторизован и присоеденён
            /// </summary>
            ATTACHED,
            /// <summary>
            /// сообщение для главного чата
            /// </summary>
            CHAT,
            /// <summary>
            /// список всех активных пользователей главного чата
            /// </summary>
            LISTUSERS,
            /// <summary>
            /// неудачная регистрация
            /// </summary>
            REGISTRATION_FAILED,
            /// <summary>
            /// неудачная регистрация по неопределённой причине
            /// </summary>
            REGISTRATION_FAILED_DEFAULT,
            /// <summary>
            /// неудачная регистрация по причине совпадения логина. 
            /// такой логин уже существует в базе
            /// </summary>
            REGISTRATION_FAILED_LOGIN_ALREADY_EXIST,
            /// <summary>
            /// ошибка формирования пакета данных на клиенте
            /// </summary>
            REGISTRATION_VERIFYDATA_ERROR,
            /// <summary>
            /// на сервер пришло ошибочное сообщение
            /// </summary>
            REFUSE,
            /// <summary>
            /// попытка повторной авторизации
            /// </summary>
            WAS_ATTACHED,
            /// <summary>
            /// попытка повторной регистрации в главном чате
            /// </summary>
            WAS_REGISTER,
            /// <summary>
            /// регистрация прошла успешно(в базу добавлена запись)
            /// </summary>
            REGISTRATION_PASSED,
            /// <summary>
            /// пользователь потерян(в случае дисконнекта)
            /// </summary>
            USERLOST,
            /// <summary>
            /// успешно вошел в главный чат
            /// </summary>
            MCHAT_ENTER_PASSED,
            /// <summary>
            /// вышел из чата
            /// </summary>
            MCHAT_EXIT,
            /// <summary>
            /// невозможно войти т.к. ошибка сервера
            /// </summary>
            MCHAT_ENTER_FAILED,
            /// <summary>
            /// ответ сервера что он действует
            /// </summary>
            SERVER_LIFE,
            AUTORIZE_FAILED_WRONG_PASSWORD,
            AUTORIZE_FAILED_NOT_REGISTERED,
            AUTORIZE_FAILED_SERVER_ERROR,
            /// <summary>
            /// в ответ на запрос клиента личных данных
            /// </summary>
            PROFILE,
            /// <summary>
            /// для отправки ответа клиенту, что на сервере произошла ошибка 
            /// и его запрос не может быть обработан
            /// </summary>
            SERVER_ERROR,
            /// <summary>
            /// отправка списка всех зарегистрированных пользователей 
            /// в ответ на запрос GET_ALL_USERS
            /// </summary>
            LIST_ALL_USERS,
            /// <summary>
            /// успешное добавление в белый список
            /// </summary>
            WHITE_ADD_PASS,
            /// <summary>
            /// ошибка при добавлении в белый список
            /// </summary>
            WHITE_ADD_ERROR,
            /// <summary>
            /// добавление невозможно т.к. такой пользователь уже есть в списке
            /// </summary>
            WHITE_ADD_WRONG,
            /// <summary>
            /// добавление невозможно т.к. такой пользователь уже есть в списке
            /// </summary>
            BLACK_ADD_WRONG,
            /// <summary>
            /// успешное добавление в чёрный список
            /// </summary>
            BLACK_ADD_PASS,
            /// <summary>
            /// ошибка при добавлении в чёрный список
            /// </summary>
            BLACK_ADD_ERROR,
            WHITE_LIST,
            BLACK_LIST,
            /// <summary>
            /// ошибка при отправке черного и белого списков 
            /// </summary>
            GET_BW_ERROR,
            /// <summary>
            /// отправка черного и белого списков завершена
            /// </summary>
            SEND_BW_FINISHED,
            /// <summary>
            /// отправка состояний из белого  спискa
            /// </summary>
            WHITE_USER_STATE,
            /// <summary>
            /// отправка состояний из  чёрного спискa
            /// </summary>
            BLACK_USER_STATE,
             /// <summary>
            /// отправка состояний черного и белого списков завершена
            /// </summary>
            SEND_BW_USER_STATE_FINISHED,
            DISCONNECT,
            ADD_CONTACT_PASS,
            ADD_CONTACT_WRONG,
            /// <summary>
            /// личное сообщение: fromUser,message,colorName,fontName,fontSize
            /// </summary>
            PRIVATE,
            EMAIL,
            /// <summary>
            /// ошибка при получении адреса почты
            /// </summary>
            EMAIL_APS


        }
        public static string MessagesGetString(MESSAGES message)
        {
           return Enum.GetName(typeof(MESSAGES), message);
        }
        #endregion

        #endregion
   }
}